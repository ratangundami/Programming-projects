import psycopg2

def user_booking(email,password,source,destination,train,date,no_of_seats):
	conn = None
	try:
		conn = psycopg2.connect(host="localhost",database="railway",user="ratangundami",password="ratangundami")
		cur = conn.cursor()
		print('Database Connection Open')

		cur.execute("""SELECT available_seat FROM train_status WHERE train_id = %s and available_date = %s """,(train,date))
		avail = cur.fetchone()
		if avail is not None:
			if(int(avail[0]) == 0):
				return "No seats available"
			else:
				pass
			avail = avail[0] - no_of_seats
			cur.execute("""SELECT booked_seats FROM train_status WHERE train_id = %s and available_date = %s """,(train,date))
			booked = cur.fetchone()
			booked = booked[0] + no_of_seats
			cur.execute("""insert into user_bookings values(%s,%s,%s,%s, %s, %s)""", (email,source,destination,train,no_of_seats,date))
			cur.execute("""UPDATE train_status SET available_seat = %s, booked_seats = %s where train_id = %s """,(str(avail),str(booked), train))				
			cur.execute("""Select * from user_bookings b where b.email_id = '%s'"""%(email))
			row = cur.fetchone()
			conn.commit()
			return row
		else:
			return "Train not available on that date"
	except (Exception, psycopg2.DatabaseError) as error:
		return error
   
	return

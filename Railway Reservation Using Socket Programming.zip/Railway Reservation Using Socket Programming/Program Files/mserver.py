import socket 
import time
import user_booking
import user
import booking_history
import train_status
import train_details
import authentication
from threading import Thread 
from SocketServer import ThreadingMixIn 

class ClientThread(Thread): 
 
    def __init__(self,ip,port): 
        Thread.__init__(self) 
        self.ip = ip 
        self.port = port 
        print "New server socket thread started for " + ip + ":" + str(port) 
 
    def run(self): 
        while True:
            	opt = str(conn.recv(1).decode())
		if(opt == '1'):
			email = conn.recv(1024).decode()
			password = conn.recv(1024).decode()
			name = conn.recv(1024).decode()
			mobile = conn.recv(1024).decode()
			user_det = str(user.user_details(email,password,name,mobile))
			conn.send(user_det.encode())

		elif(opt == '2'):
			s_list,t_list,st_list = train_details.details()
			s_len = len(s_list)-1			
			conn.send(str(s_len).encode())
			time.sleep(0.5)
			for i in range(s_len):
				conn.send(s_list[i].encode())
				time.sleep(0.5)
			t_len = len(t_list)-1			
			conn.send(str(t_len).encode())
			time.sleep(0.5)
			for i in range(t_len):
				conn.send(t_list[i].encode())
				time.sleep(0.5)
			st_len = len(st_list)-1			
			conn.send(str(st_len).encode())
			time.sleep(0.5)
			for i in range(st_len):
				conn.send(st_list[i].encode())
				time.sleep(0.5)

		elif(opt == '3'):
			email = conn.recv(1024).decode()
			password = conn.recv(1024).decode()
			auth = str(authentication.verify(email,password))
			conn.send(auth.encode())
			if auth == '1':
				source = conn.recv(1024).decode()
				destination = conn.recv(1024).decode()
				train = conn.recv(1024).decode()
				date = conn.recv(1024).decode()
				no_of_seats = int(conn.recv(1024).decode())
				row = str(user_booking.user_booking(email,password,source,destination,train,date,no_of_seats))
				conn.send(row.encode())
			else :
				pass

		
		elif(opt == '4'):
			email = conn.recv(1024).decode()
			password = conn.recv(1024).decode()
			auth = str(authentication.verify(email,password))
			conn.send(auth.encode())
			time.sleep(0.5)
			if auth == '1':
				d_list = booking_history.booking_history(email,password)
				d_len = len(d_list)-1
				conn.send(str(d_len).encode())
				time.sleep(0.5)
				for i in range(d_len):
					conn.send(d_list[i].encode())
					time.sleep(0.5)
			else :
				pass

		elif(opt == '5'):
			trainID = conn.recv(1024).decode()
			t_det = str(train_status.train_stat(trainID))
			conn.send(t_det.encode())

		elif(opt == '6'):
			break

	conn.close()


TCP_IP = '0.0.0.0' 
TCP_PORT = 2004 
BUFFER_SIZE = 200

tcpServer = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
tcpServer.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) 
tcpServer.bind((TCP_IP, TCP_PORT)) 
threads = [] 
 
while True: 
    tcpServer.listen(4) 
    print "Multithreaded Python server : Waiting for connections from TCP clients..." 
    (conn, (ip,port)) = tcpServer.accept() 
    newthread = ClientThread(ip,port) 
    newthread.start() 
    threads.append(newthread) 
    print("Threads %s "%(threads))
 
for t in threads: 
    t.join() 

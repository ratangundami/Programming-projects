create table user_details(email_id varchar(30) primary key, password varchar(15) not null, name varchar(30) not null,  mobile varchar(14) not null);

create table station(station_id varchar(8) primary key, station_name varchar(25));

create table train(train_id varchar(10) primary key, train_name varchar(50) not null, source_id varchar(8), dest_id varchar(8), seats int not null, fare int not null,foreign key(source_id) references station(station_id) on update cascade on delete cascade, foreign key(dest_id) references station(station_id) on update no action on delete no action);

create table train_status(train_id varchar(10), available_date varchar(20), booked_seats int, available_seat int, primary key(train_id,available_date),foreign key(train_id) references train(train_id) on update cascade on delete cascade);

create table user_bookings(email_id varchar(30) primary key,source_id varchar(30) not null,dest_id varchar(30) not null,train_id varchar(10) not null,no_of_seats varchar(1),date_id varchar(10),foreign key(dest_id) references station(station_id),foreign key(source_id) references station(station_id),foreign key(train_id) references train(train_id)); 

insert into user_details values('ratangundami@gmail.com','12345','Ratan Gundami','M','8050884084','Dharwad','Karnataka');
insert into user_details values('akshatchopra@gmail.com','abcde','Akshat Chopra','M','9449504876','Jaipur','Rajasthan');
insert into user_details values('kushaln@gmail.com','abcd123','Kushal Nagaraj','M','9880599055','Bengaluru','Karnataka');
insert into user_details values('sanjeshaj@gmail.com','sanjesh','Sanjesh AJ','M','90471894999','Chennai','Tamil Nadu');
 
insert into station values('DDN','Dehradun');
insert into station values('BDTS','Bandra Terminus');
 
insert into train values(19020,'Dehradun Express','Express','DDN','BDTS',200,700);
insert into train values(12431,'Rajdhani Express','Express','TVC','NZM',200,800);
insert into train values(12010,'Shatabdi Express','Express','ADI','BCT',200,1025);
insert into train values(15008,'LJN BCY Express','Express','LJN','BCY',75,256);
insert into train values(11464,'JBP Somnath Express','Express','JBP','SMNH',75,520);

insert into train_status values(19020, '27/11/2017', 0, 200);




GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA PUBLIC TO pooja;

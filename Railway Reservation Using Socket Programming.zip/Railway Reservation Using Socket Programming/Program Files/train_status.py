import psycopg2

def train_stat(trainID):
	conn = None
	try:
        	conn = psycopg2.connect(host="localhost",database="railway",user="ratangundami",password="ratangundami")
        	cur = conn.cursor()
        	print('Database Connection Open')

		cur.execute("""SELECT s.train_id, t.train_name, t.source_id, t.dest_id, s.available_date, s.available_seat from train_status s, train t where s.train_id= %s and t.train_id= %s  """,(trainID,trainID))
		row = cur.fetchone()
        	conn.commit()
		if row is not None:
			return row
		else :
			return "Train Status not available"
        
   	except (Exception, psycopg2.DatabaseError) as error:
        	return error
   
   	menu.menu()
   	return

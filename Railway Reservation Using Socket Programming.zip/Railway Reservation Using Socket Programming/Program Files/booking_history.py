import psycopg2
def booking_history(email,password):
   conn = None
   try:
        conn = psycopg2.connect(host="localhost",database="railway",user="ratangundami",password="ratangundami")
        cur = conn.cursor()
        print('Database Connection Open')
        
	cur.execute("""Select * from user_bookings b where b.email_id = '%s'"""%(email))
	s_list=[]	
	row = cur.fetchone()
	s_list.append(str(row))
	while row is not None:
		row = cur.fetchone()
		s_list.append(str(row))
	
        conn.commit()

	return s_list
        
   except (Exception, psycopg2.DatabaseError) as error:
        return error
   
   return
   

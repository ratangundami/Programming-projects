import psycopg2

def user_details(email,password,name,mobile):
   conn = None
   try:
        conn = psycopg2.connect(host="localhost",database="railway",user="ratangundami",password="ratangundami")
        cur = conn.cursor()
        print('Database Connection Open')
        cur.execute("""insert into user_details values(%s,%s,%s,%s)""",(email,password,name,mobile))
        cur.execute("""select * from user_details where email_id = '%s'""" %(email))
        row = cur.fetchone()
        conn.commit()
	
	return row

   except (Exception, psycopg2.DatabaseError) as error:
        print(error)
   return
   

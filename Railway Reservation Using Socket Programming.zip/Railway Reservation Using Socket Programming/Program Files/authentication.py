import psycopg2

def verify(email,password):
	conn = None
	try:
		conn = psycopg2.connect(host="localhost",database="railway",user="ratangundami",password="ratangundami")
		cur = conn.cursor()
		cur.execute("""SELECT * FROM user_details u where u.email_id = %s and u.password = %s""",(email,password))		
		row = cur.fetchone()
		if row is not None:
			return 1


		return 0
	except (Exception, psycopg2.DatabaseError) as error:
		return error
   
	return

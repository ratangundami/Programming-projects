import psycopg2

def details():
	conn = None
	try:
		conn = psycopg2.connect(host="localhost",database="railway",user="ratangundami",password="ratangundami")
		cur = conn.cursor()
		print('Database Connection Open')
		cur.execute("""select * from station""")
		s_list = []		
		station = cur.fetchone()
		s_list.append(str(station))
		while station is not None:
			station = cur.fetchone()
			s_list.append(str(station))

		cur.execute("""select * from train""")
		t_list = []
		trains = cur.fetchone()
		t_list.append(str(trains))
		while trains is not None:
			trains = cur.fetchone()
			t_list.append(str(trains))

		cur.execute("""select * from train_status""")
		status_list = []		
		tstatus = cur.fetchone()
		status_list.append(str(tstatus))	
		while tstatus is not None:
			tstatus = cur.fetchone()
			status_list.append(str(tstatus))		

		
		conn.commit()
		return s_list,t_list,status_list

	except (Exception, psycopg2.DatabaseError) as error:
		return error
   
	return


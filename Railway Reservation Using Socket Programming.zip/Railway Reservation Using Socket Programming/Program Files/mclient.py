import socket 
import time

def display():

	print("Menu :\n")
	print("1. Sign - up\n")
	print("2. Train Details\n")
	print("3. Make a Booking\n")
	print("4. Booking History\n")
	print("5. Display the train status based on train_id\n")
	print("6. Exit\n")
	opt = str(raw_input("Enter your option : "))
	return opt

def opt1():
	email = raw_input("Enter your email id : ")
	password = raw_input("Enter your password : ")
	name = raw_input("Enter your name : ")
	mobile = raw_input("Enter your mobile no. : ")
        client_socket.send(opt.encode())
	time.sleep(0.5)
        client_socket.send(email.encode())
	time.sleep(0.5)
        client_socket.send(password.encode())
	time.sleep(0.5)
        client_socket.send(name.encode())
	time.sleep(0.5)
        client_socket.send(mobile.encode())
	time.sleep(0.5)
	print("-----------------------------------------------------------------------------------------")
	print("User Successfully Registered")
	print("-----------------------------------------------------------------------------------------")
	print("User details : %s "%(client_socket.recv(1024).decode()))
	print("-----------------------------------------------------------------------------------------")

def opt2():
        client_socket.send(opt.encode())
	print("-----------------------------------------------------------------------------------------")
	print("Station Details : ")
	s_len = int(client_socket.recv(1024).decode())
	for i in range(s_len):
		print(client_socket.recv(1024).decode())
	print("-----------------------------------------------------------------------------------------")

	print("Train Details : ")	
	t_len = int(client_socket.recv(1024).decode())
	for i in range(t_len):
		print(client_socket.recv(1024).decode())
	print("-----------------------------------------------------------------------------------------")
	
	print("Available Trains : ")
	st_len = int(client_socket.recv(1024).decode())
	for i in range(st_len):
		print(client_socket.recv(1024).decode())
	print("-----------------------------------------------------------------------------------------")		

def opt3():
   	email = raw_input("Enter your email id : ")
	password = raw_input("Enter your password : ")
        client_socket.send(opt.encode())
	time.sleep(0.5)
        client_socket.send(email.encode())
	time.sleep(0.5)
        client_socket.send(password.encode())
	time.sleep(0.5)
	ver = str(client_socket.recv(1024).decode())
	if(ver == '1'):
		print("User Verified.")
		print("-----------------------------------------------------------------------------------------")
		source = raw_input("Enter the source_id : ")
		destination = raw_input("Enter the destination_id : ")
		train = raw_input("Train_id : ")
		date = raw_input("Date of Journey in (dd/mm/yyyy) : ")
		no_of_seats = raw_input("Enter the required number of seats : ")
		client_socket.send(source.encode())
		time.sleep(0.5)
        	client_socket.send(destination.encode())
		time.sleep(0.5)
		client_socket.send(train.encode())
		time.sleep(0.5)
        	client_socket.send(date.encode())
		time.sleep(0.5)
        	client_socket.send(no_of_seats.encode())
		time.sleep(0.5)
		res = client_socket.recv(1024).decode()
		if res == 'Train not available on that date':
			print(res)
		else:		
			print("-----------------------------------------------------------------------------------------")
			print("Ticket Successfully Booked")
			print("-----------------------------------------------------------------------------------------")
			print("Ticket Details : %s"%(res))
			print("-----------------------------------------------------------------------------------------")
	else:
		print("Invalid User")

def opt4():
	email = raw_input("Enter your email id : ")
	password = raw_input("Enter you password : ")
        client_socket.send(opt.encode())
	time.sleep(0.5)
        client_socket.send(email.encode())
	time.sleep(0.5)
        client_socket.send(password.encode())
	time.sleep(0.5)
	ver = str(client_socket.recv(1024).decode())
	if(ver == '1'):
		print("User Verified.")
		print("Ticket Details : ") 
		s_len = int(client_socket.recv(1024).decode())
		for i in range(s_len):
			print("-----------------------------------------------------------------------------------------")
			print(client_socket.recv(1024).decode())
			print("-----------------------------------------------------------------------------------------")

	else:
		print("Invalid User")

def opt5():
	trainID=raw_input("Enter train_id : ")
        client_socket.send(opt.encode())
	time.sleep(0.5)
        client_socket.send(trainID.encode())
	time.sleep(0.5)
	print("-----------------------------------------------------------------------------------------")
	print("Train Status : %s"%(client_socket.recv(1024).decode()))
	print("-----------------------------------------------------------------------------------------")

host = socket.gethostname() 
port = 2004
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
client_socket.connect((host, port))
print("\n")
print("************************************* Welcome to Railway Reservation System *************************************\n")
opt  = display();
while True:
	if(opt == '1'):
		opt1();

	elif(opt == '2'):
		opt2();

	elif(opt == '3'):
		opt3();

	elif(opt == '4'):
		opt4();

	elif(opt == '5'):
		opt5();

	elif(opt == '6'):
        	client_socket.send(opt.encode())
		exit(0)
	else:
		print("-----------------------------------------------------------------------------------------")
		print("Invalid Option !!! Please Enter valid option")
		print("-----------------------------------------------------------------------------------------")
	opt = display()

client_socket.close() 
